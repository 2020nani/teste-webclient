package com.webfluxrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebfluxRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
